# GrantFlow Migration Package

This package contains everything needed to migrate GrantFlow from Base44 to a self-hosted Vercel + Railway stack.

## 📁 Package Contents

```
grantflow-migration/
├── MIGRATION_GUIDE.md      # Detailed instructions for Cursor
├── .env.example            # Environment variable template
├── data-export.json        # Your Base44 data export (1000+ opportunities!)
│
├── backend/                # Railway Backend (Express + SQLite)
│   ├── server.js          # Main server entry point
│   ├── package.json       # Dependencies
│   ├── import-data.js     # Script to import Base44 data
│   ├── db/
│   │   └── schema.sql     # Database schema
│   └── routes/
│       ├── organizations.js
│       ├── grants.js
│       ├── opportunities.js
│       ├── milestones.js
│       ├── documents.js
│       ├── expenses.js
│       ├── ai.js          # OpenAI integration
│       └── anya.js        # Compatibility routes
│
└── src/                    # Vercel Frontend (React + Vite)
    ├── api/
    │   ├── client.js      # NEW API client (replaces Base44 SDK)
    │   └── base44Client.js # Compatibility wrapper
    ├── pages/              # 33 pages from Base44
    ├── components/         # All UI components
    ├── hooks/             # React hooks
    └── ...
```

## 🚀 Quick Start for Cursor

### Step 1: Copy Backend Files

Copy the `backend/` folder to your GrantFlow repository, replacing the existing backend.

### Step 2: Update Frontend API Client

Replace `src/api/base44Client.js` with the new `src/api/client.js` (or use the compatibility wrapper).

### Step 3: Add Environment Variables

**In Railway Dashboard:**
```
PORT=8080
NODE_ENV=production
OPENAI_API_KEY=your-key-here
CORS_ORIGIN=https://grant-flow-three.vercel.app,https://app.axiombiolabs.org
ADMIN_TOKEN=your-admin-token
```

**In Vercel Dashboard:**
```
VITE_API_URL=https://grantflow-production.up.railway.app
```

### Step 4: Import Your Data

```bash
cd backend
npm install
node import-data.js ../data-export.json
```

### Step 5: Deploy

- Push to GitHub
- Railway will auto-deploy backend
- Vercel will auto-deploy frontend

## 📋 What's Included from Base44

### Pages (33 total)
- Dashboard, Organizations, Pipeline
- DiscoverGrants, ProfileMatcher, AIGrantScorer
- GrantDetail, GrantMonitoring, Proposals
- Billing, Budgets, Documents, Calendar
- Reports, Stewardship, and more...

### Components
- All shadcn/ui components
- Dashboard cards
- Pipeline/Kanban components
- Organization forms
- Search and filter components

### Data
- 13 Organizations
- 118 Grants
- 1,000 Funding Opportunities
- 44 Application Drafts
- 17 Documents
- 12 Milestones

## ⚠️ Important Notes

1. **API Keys** - Never commit API keys to git. Use environment variables only.

2. **Base44 SDK Calls** - The new `client.js` provides the same interface as Base44 SDK. Existing code like `base44.entities.Organization.list()` will work.

3. **Database** - Uses SQLite for simplicity. The schema supports all Base44 entities.

4. **AI Features** - Requires OpenAI API key. Grant matching and proposal generation use GPT-4o-mini.

## 🔧 For Cursor: Key Changes Needed

1. **Replace imports:**
   ```js
   // Old (Base44)
   import { base44 } from '@/api/base44Client';
   
   // New (same interface, different backend)
   import { base44 } from '@/api/client';
   ```

2. **Update API calls** (if any use Base44-specific features):
   - `base44.entities.X.list()` → Works as-is
   - `base44.entities.X.filter()` → Works as-is
   - `base44.functions.invoke()` → Works as-is

3. **Authentication:**
   - Base44 auth is replaced with simple token auth
   - Token stored in sessionStorage
   - Use `base44.auth.login(token)` to authenticate

4. **Remove Base44 dependencies:**
   ```bash
   npm uninstall @base44/sdk
   ```

## 📞 Support

Refer to MIGRATION_GUIDE.md for detailed step-by-step instructions.

The frontend pages are copied from your Base44 app and should work with minimal changes once the API client is updated.
