# GrantFlow Migration Guide

## Overview

This guide instructs Cursor (or any AI assistant) to migrate GrantFlow from Base44 to a self-hosted Vercel + Railway stack.

**Current State:** Basic admin dashboard with minimal functionality
**Target State:** Full grant management system with 30+ pages, AI matching, and data management

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Vercel        │────▶│   Railway       │────▶│   SQLite DB     │
│   (Frontend)    │     │   (Backend API) │     │   (on Railway)  │
│   React + Vite  │     │   Express.js    │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │
                               ▼
                        ┌─────────────────┐
                        │   OpenAI API    │
                        │   (AI Features) │
                        └─────────────────┘
```

## Environment Variables

### Frontend (Vercel Dashboard → Settings → Environment Variables)
```
VITE_API_URL=https://grantflow-production.up.railway.app
VITE_APP_NAME=GrantFlow
```

### Backend (Railway Dashboard → Service → Variables)
```
PORT=8080
NODE_ENV=production
DATABASE_URL=./data/grantflow.db
OPENAI_API_KEY=<your-openai-key>
CORS_ORIGIN=https://grant-flow-three.vercel.app,https://app.axiombiolabs.org
JWT_SECRET=<generate-a-random-32-char-string>
ADMIN_TOKEN=<your-admin-token>
```

⚠️ **NEVER put actual API keys in code files. Always use environment variables.**

---

## Database Schema

### Core Entities

```sql
-- Organizations (clients/applicants)
CREATE TABLE organizations (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  applicant_type TEXT, -- 'individual_need', 'nonprofit', 'small_business', etc.
  
  -- Demographics
  date_of_birth DATE,
  age INTEGER,
  
  -- Address
  address TEXT,
  city TEXT,
  state TEXT,
  zip TEXT,
  
  -- Organization Details (for nonprofits)
  ein TEXT,
  uei TEXT,
  organization_type TEXT,
  nonprofit_type TEXT,
  annual_budget REAL,
  staff_count INTEGER,
  mission TEXT,
  
  -- Education (for students)
  current_college TEXT,
  intended_major TEXT,
  gpa REAL,
  first_generation BOOLEAN DEFAULT FALSE,
  
  -- Financial
  household_income REAL,
  household_size INTEGER,
  
  -- Benefits
  medicaid_enrolled BOOLEAN DEFAULT FALSE,
  snap_recipient BOOLEAN DEFAULT FALSE,
  ssi_recipient BOOLEAN DEFAULT FALSE,
  veteran BOOLEAN DEFAULT FALSE,
  disabled BOOLEAN DEFAULT FALSE,
  
  -- Matching
  keywords TEXT, -- JSON array
  focus_areas TEXT, -- JSON array
  program_areas TEXT, -- JSON array
  funding_amount_needed TEXT
);

-- Grants (opportunities being tracked)
CREATE TABLE grants (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  organization_id TEXT REFERENCES organizations(id),
  funding_opportunity_id TEXT REFERENCES funding_opportunities(id),
  
  title TEXT NOT NULL,
  funder TEXT,
  amount_requested REAL,
  amount_awarded REAL,
  
  status TEXT DEFAULT 'discovered', 
  -- 'discovered', 'interested', 'drafting', 'app_prep', 'submitted', 'awarded', 'rejected', 'closed'
  
  deadline DATE,
  submitted_date DATE,
  award_date DATE,
  
  match_score INTEGER,
  match_reasons TEXT, -- JSON array
  notes TEXT,
  
  application_url TEXT,
  portal_credentials TEXT -- encrypted
);

-- Funding Opportunities (master list of available grants)
CREATE TABLE funding_opportunities (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  
  title TEXT NOT NULL,
  sponsor TEXT,
  source TEXT, -- 'grants.gov', 'foundation', 'state', etc.
  source_id TEXT, -- external ID from source
  
  description TEXT,
  eligibility_bullets TEXT, -- JSON array
  
  amount_min REAL,
  amount_max REAL,
  
  deadline DATE,
  deadline_type TEXT, -- 'fixed', 'rolling', 'ongoing'
  
  application_url TEXT,
  
  -- Geographic
  is_national BOOLEAN DEFAULT FALSE,
  state TEXT,
  regions TEXT, -- JSON array
  
  -- Categories
  categories TEXT, -- JSON array
  keywords TEXT, -- JSON array
  
  -- Status
  is_active BOOLEAN DEFAULT TRUE,
  last_crawled DATETIME
);

-- Milestones
CREATE TABLE milestones (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  grant_id TEXT REFERENCES grants(id),
  
  title TEXT NOT NULL,
  description TEXT,
  due_date DATE,
  completed BOOLEAN DEFAULT FALSE,
  completed_date DATE
);

-- Documents
CREATE TABLE documents (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  organization_id TEXT REFERENCES organizations(id),
  grant_id TEXT REFERENCES grants(id),
  
  name TEXT NOT NULL,
  type TEXT, -- 'proposal', 'budget', 'letter', 'form', etc.
  file_url TEXT,
  file_size INTEGER,
  mime_type TEXT,
  
  status TEXT DEFAULT 'draft' -- 'draft', 'review', 'final'
);

-- Expenses
CREATE TABLE expenses (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  grant_id TEXT REFERENCES grants(id),
  
  description TEXT NOT NULL,
  amount REAL NOT NULL,
  category TEXT,
  date DATE,
  receipt_url TEXT
);

-- Application Drafts
CREATE TABLE application_drafts (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  grant_id TEXT REFERENCES grants(id),
  
  section_name TEXT,
  content TEXT,
  ai_suggestions TEXT,
  status TEXT DEFAULT 'draft'
);

-- Crawl Logs (for tracking data imports)
CREATE TABLE crawl_logs (
  id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  source TEXT NOT NULL,
  status TEXT, -- 'success', 'error', 'partial'
  records_found INTEGER,
  records_imported INTEGER,
  error_message TEXT
);
```

---

## Backend API Routes

### File: `backend/routes/organizations.js`
```javascript
import express from 'express';
import { db } from '../db/index.js';

const router = express.Router();

// List all organizations
router.get('/', async (req, res) => {
  try {
    const orgs = db.prepare('SELECT * FROM organizations ORDER BY created_at DESC').all();
    res.json(orgs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single organization
router.get('/:id', async (req, res) => {
  try {
    const org = db.prepare('SELECT * FROM organizations WHERE id = ?').get(req.params.id);
    if (!org) return res.status(404).json({ error: 'Not found' });
    res.json(org);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create organization
router.post('/', async (req, res) => {
  try {
    const id = crypto.randomUUID();
    const { name, email, phone, applicant_type, state, city, ...rest } = req.body;
    
    db.prepare(`
      INSERT INTO organizations (id, name, email, phone, applicant_type, state, city)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, email, phone, applicant_type, state, city);
    
    const org = db.prepare('SELECT * FROM organizations WHERE id = ?').get(id);
    res.status(201).json(org);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update organization
router.put('/:id', async (req, res) => {
  try {
    const fields = Object.keys(req.body);
    const values = Object.values(req.body);
    
    const setClause = fields.map(f => `${f} = ?`).join(', ');
    db.prepare(`UPDATE organizations SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
      .run(...values, req.params.id);
    
    const org = db.prepare('SELECT * FROM organizations WHERE id = ?').get(req.params.id);
    res.json(org);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete organization
router.delete('/:id', async (req, res) => {
  try {
    db.prepare('DELETE FROM organizations WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
```

### Similar routes needed for:
- `/api/grants` - Grant CRUD + status updates
- `/api/opportunities` - Funding opportunities listing + search
- `/api/milestones` - Milestone tracking
- `/api/documents` - Document management
- `/api/expenses` - Expense tracking
- `/api/match` - AI-powered grant matching

---

## Frontend Pages to Build

### Priority 1 (Core)
1. **Dashboard** - Stats, pipeline overview, upcoming deadlines
2. **Organizations** - List, create, edit profiles
3. **OrganizationProfile** - Detailed view with all sections
4. **Pipeline** - Kanban board for grant workflow
5. **DiscoverGrants** - Search and browse opportunities

### Priority 2 (Management)
6. **GrantDetail** - Full grant view with milestones, documents
7. **Proposals** - Proposal writing and editing
8. **ProfileMatcher** - Match profiles to grants with AI
9. **Calendar** - Deadline tracking

### Priority 3 (Advanced)
10. **Billing** - Invoice generation
11. **Reports** - Analytics and reporting
12. **Documents** - File management
13. **GrantMonitoring** - Track active grants

---

## Key Components to Port

### From Base44 Export (in `/base44-source/`):

1. **Layout.jsx** - Main app layout with sidebar navigation
2. **Dashboard components**:
   - StatCard.jsx
   - UrgentDeadlinesCard.jsx
   - RecentGrantsCard.jsx
3. **Pipeline components**:
   - PipelineColumn.jsx
   - GrantCard.jsx
4. **Organization components**:
   - OrganizationForm.jsx
   - ProfileSections.jsx
5. **Discovery components**:
   - SearchFilters.jsx
   - OpportunityCard.jsx
   - MatchScoreBadge.jsx

---

## AI Integration

### Grant Matching Function

Replace Base44's AI functions with direct OpenAI calls:

```javascript
// backend/routes/ai.js
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

router.post('/match', async (req, res) => {
  const { profile, opportunities } = req.body;
  
  const prompt = `
    Given this applicant profile:
    ${JSON.stringify(profile, null, 2)}
    
    Score these grant opportunities from 0-100 based on eligibility match:
    ${JSON.stringify(opportunities.slice(0, 20), null, 2)}
    
    Return JSON array with: { id, score, reasons: string[] }
  `;
  
  const completion = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: prompt }],
    response_format: { type: 'json_object' }
  });
  
  res.json(JSON.parse(completion.choices[0].message.content));
});
```

---

## Migration Steps for Cursor

### Step 1: Backend Setup
1. Update `backend/server.js` with new routes
2. Create database schema in `backend/db/schema.sql`
3. Add migration script to initialize tables
4. Test all API endpoints

### Step 2: Frontend Foundation
1. Install dependencies: `npm install @tanstack/react-query lucide-react date-fns`
2. Set up React Query provider
3. Create API client in `src/api/client.js`
4. Update routing in `src/App.jsx`

### Step 3: Port Pages
1. Copy Layout from Base44 source, adapt imports
2. Build Dashboard with stat cards
3. Build Organizations list and form
4. Build Pipeline with drag-and-drop
5. Build DiscoverGrants with search

### Step 4: AI Features
1. Add OpenAI route to backend
2. Build ProfileMatcher page
3. Integrate match scores in discovery

### Step 5: Polish
1. Add loading states
2. Add error handling
3. Add empty states
4. Test responsive design

---

## File Structure

```
grantflow/
├── backend/
│   ├── server.js           # Express server entry
│   ├── db/
│   │   ├── index.js        # Database connection
│   │   └── schema.sql      # Table definitions
│   ├── routes/
│   │   ├── organizations.js
│   │   ├── grants.js
│   │   ├── opportunities.js
│   │   ├── milestones.js
│   │   ├── documents.js
│   │   └── ai.js
│   └── middleware/
│       └── auth.js
├── src/
│   ├── api/
│   │   └── client.js       # API client with React Query
│   ├── components/
│   │   ├── ui/             # shadcn components
│   │   ├── dashboard/
│   │   ├── pipeline/
│   │   ├── organizations/
│   │   └── shared/
│   ├── pages/
│   │   ├── Dashboard.jsx
│   │   ├── Organizations.jsx
│   │   ├── OrganizationProfile.jsx
│   │   ├── Pipeline.jsx
│   │   ├── DiscoverGrants.jsx
│   │   ├── GrantDetail.jsx
│   │   ├── ProfileMatcher.jsx
│   │   └── ...
│   ├── contexts/
│   │   └── AuthContext.jsx
│   ├── hooks/
│   │   └── useOrganizations.js
│   ├── lib/
│   │   └── utils.js
│   └── App.jsx
├── .env.example
├── package.json
└── vercel.json
```

---

## Testing Checklist

- [ ] Organizations CRUD works
- [ ] Grants can be created and moved through pipeline
- [ ] Funding opportunities can be searched
- [ ] AI matching returns scored results
- [ ] Dashboard shows correct stats
- [ ] All pages are responsive
- [ ] Authentication works
- [ ] Data persists across sessions

---

## Notes for Cursor

1. **Don't use Base44 SDK** - Replace all `base44.entities.X` calls with fetch to `/api/X`
2. **Use React Query** for data fetching - it's already a dependency
3. **Keep the UI style** - Use the same Tailwind classes from Base44 source
4. **shadcn/ui components** are already installed - use them
5. **Test incrementally** - Get each page working before moving to the next
