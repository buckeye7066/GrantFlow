/**
 * matchGrantsForOrganization - AI-powered grant matching for organizations
 * 
 * @version 2.0.0 - Robust payload parsing to handle all wrapper formats
 * 
 * Handles three payload formats:
 * 1. Direct: { organization_id: "..." }
 * 2. Single-wrapped: { body: { organization_id: "..." } }
 * 3. Double-wrapped: { body: { body: { organization_id: "..." } } }
 */

import sdk from '@base44/sdk';
sdk.auth.setAuthHeader(); // Authenticate with Base44

// ID validation patterns
const MONGODB_ID_PATTERN = /^[0-9a-f]{24}$/i;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isValidId(id) {
  if (!id || typeof id !== 'string') return false;
  const trimmed = id.trim();
  return MONGODB_ID_PATTERN.test(trimmed) || UUID_PATTERN.test(trimmed);
}

/**
 * Parse payload handling all wrapper formats
 * @param {any} input - Raw input from request
 * @returns {{ organization_id: string, min_score?: number, max_results?: number }}
 */
function parsePayload(input) {
  console.log('[matchGrantsForOrganization] Raw input type:', typeof input);
  console.log('[matchGrantsForOrganization] Raw input:', JSON.stringify(input).slice(0, 500));
  
  let parsed = input;
  
  // Handle string input (shouldn't happen but just in case)
  if (typeof input === 'string') {
    try {
      parsed = JSON.parse(input);
    } catch (e) {
      console.error('[matchGrantsForOrganization] Failed to parse string input');
      return { organization_id: null };
    }
  }
  
  if (!parsed || typeof parsed !== 'object') {
    console.error('[matchGrantsForOrganization] Invalid input - not an object');
    return { organization_id: null };
  }
  
  let body = parsed;
  
  // Unwrap: { body: { body: { ... } } } -> { ... }
  if (parsed.body && typeof parsed.body === 'object') {
    if (parsed.body.body && typeof parsed.body.body === 'object') {
      console.log('[matchGrantsForOrganization] Detected DOUBLE-wrapped payload');
      body = parsed.body.body;
    } else {
      console.log('[matchGrantsForOrganization] Detected SINGLE-wrapped payload');
      body = parsed.body;
    }
  } else {
    console.log('[matchGrantsForOrganization] Detected DIRECT payload (no wrapper)');
  }
  
  console.log('[matchGrantsForOrganization] Extracted body:', JSON.stringify(body));
  
  return {
    organization_id: body.organization_id || body.profile_id || null,
    min_score: body.min_score || 70,
    max_results: body.max_results || 50
  };
}

export default async function handler(input) {
  const startTime = Date.now();
  
  try {
    console.log('[matchGrantsForOrganization] === START ===');
    
    // Step 1: Parse payload
    const { organization_id, min_score, max_results } = parsePayload(input);
    
    console.log('[matchGrantsForOrganization] Parsed values:', { 
      organization_id, 
      min_score, 
      max_results 
    });
    
    // Step 2: Validate organization_id
    if (!organization_id) {
      console.error('[matchGrantsForOrganization] MISSING organization_id');
      return {
        ok: false,
        error: 'Missing organization_id in request payload',
        debug: {
          received_input_type: typeof input,
          received_keys: input ? Object.keys(input) : []
        }
      };
    }
    
    if (!isValidId(organization_id)) {
      console.error('[matchGrantsForOrganization] INVALID organization_id format:', organization_id);
      return {
        ok: false,
        error: `Invalid organization_id format: ${organization_id}`,
        debug: {
          organization_id,
          valid_formats: ['24-char hex (MongoDB)', 'UUID v4']
        }
      };
    }
    
    console.log('[matchGrantsForOrganization] Valid organization_id:', organization_id);
    
    // Step 3: Fetch organization
    let organization;
    try {
      const orgs = await sdk.entities.Organization.filter({ id: organization_id });
      organization = orgs?.[0];
      
      if (!organization) {
        console.error('[matchGrantsForOrganization] Organization not found:', organization_id);
        return {
          ok: false,
          error: `Organization not found: ${organization_id}`
        };
      }
      
      console.log('[matchGrantsForOrganization] Found organization:', organization.name);
    } catch (err) {
      console.error('[matchGrantsForOrganization] Error fetching organization:', err.message);
      return {
        ok: false,
        error: `Failed to fetch organization: ${err.message}`
      };
    }
    
    // Step 4: Fetch funding opportunities
    let opportunities = [];
    try {
      opportunities = await sdk.entities.FundingOpportunity.list('-created_date', 500);
      console.log('[matchGrantsForOrganization] Fetched', opportunities.length, 'opportunities');
    } catch (err) {
      console.error('[matchGrantsForOrganization] Error fetching opportunities:', err.message);
      return {
        ok: false,
        error: `Failed to fetch opportunities: ${err.message}`
      };
    }
    
    // Step 5: Fetch existing pipeline grants
    let existingGrants = [];
    try {
      existingGrants = await sdk.entities.Grant.filter({ 
        organization_id: organization_id 
      });
      console.log('[matchGrantsForOrganization] Found', existingGrants.length, 'existing pipeline grants');
    } catch (err) {
      console.warn('[matchGrantsForOrganization] Could not fetch existing grants:', err.message);
    }
    
    const existingOpportunityIds = new Set(
      existingGrants.map(g => g.opportunity_id || g.funding_opportunity_id).filter(Boolean)
    );
    
    // Step 6: Score opportunities
    const matches = [];
    
    for (const opp of opportunities) {
      // Skip if already in pipeline
      if (existingOpportunityIds.has(opp.id)) {
        continue;
      }
      
      // Skip if expired
      if (opp.deadlineAt) {
        const deadline = new Date(opp.deadlineAt);
        if (deadline < new Date() && !opp.rolling) {
          continue;
        }
      }
      
      // Calculate match score
      const score = calculateMatchScore(organization, opp);
      
      if (score >= min_score) {
        matches.push({
          id: opp.id,
          title: opp.title,
          sponsor: opp.sponsor,
          fundingType: opp.fundingType,
          awardMin: opp.awardMin,
          awardMax: opp.awardMax,
          deadlineAt: opp.deadlineAt,
          rolling: opp.rolling,
          url: opp.url,
          descriptionMd: opp.descriptionMd?.slice(0, 500),
          eligibilityBullets: opp.eligibilityBullets,
          categories: opp.categories,
          match_score: score,
          match_reasons: getMatchReasons(organization, opp, score),
          ai_explanation: null // Will be populated below for high matches
        });
      }
    }
    
    // Sort by score descending
    matches.sort((a, b) => b.match_score - a.match_score);
    
    // Limit results
    const topMatches = matches.slice(0, max_results);
    
    console.log('[matchGrantsForOrganization] Found', topMatches.length, 'matches above', min_score, '%');
    
    // Step 7: Generate AI explanations for top matches (score >= 80)
    const highMatches = topMatches.filter(m => m.match_score >= 80).slice(0, 10);
    
    if (highMatches.length > 0) {
      console.log('[matchGrantsForOrganization] Generating AI explanations for', highMatches.length, 'high matches');
      
      try {
        for (const match of highMatches) {
          const explanation = await generateMatchExplanation(organization, match);
          match.ai_explanation = explanation;
        }
      } catch (err) {
        console.warn('[matchGrantsForOrganization] AI explanation generation failed:', err.message);
      }
    }
    
    const elapsed = Date.now() - startTime;
    console.log('[matchGrantsForOrganization] === COMPLETE === elapsed:', elapsed, 'ms');
    
    return {
      ok: true,
      data: {
        organization: {
          id: organization.id,
          name: organization.name
        },
        total_opportunities_analyzed: opportunities.length,
        matches_found: topMatches.length,
        matches: topMatches,
        elapsed_ms: elapsed
      }
    };
    
  } catch (err) {
    console.error('[matchGrantsForOrganization] Unhandled error:', err);
    return {
      ok: false,
      error: err.message || 'Unknown error',
      stack: err.stack?.split('\n').slice(0, 5)
    };
  }
}

/**
 * Calculate match score between organization and opportunity
 * @param {object} org - Organization profile
 * @param {object} opp - Funding opportunity
 * @returns {number} Score 0-100
 */
function calculateMatchScore(org, opp) {
  let score = 0;
  let maxScore = 0;
  
  // 1. Eligibility check (30 points)
  maxScore += 30;
  if (checkEligibility(org, opp)) {
    score += 30;
  }
  
  // 2. Focus area alignment (25 points)
  maxScore += 25;
  const focusScore = calculateFocusAlignment(org, opp);
  score += focusScore * 0.25;
  
  // 3. Geographic match (15 points)
  maxScore += 15;
  if (checkGeographicMatch(org, opp)) {
    score += 15;
  }
  
  // 4. Award amount fit (15 points)
  maxScore += 15;
  if (checkAwardFit(org, opp)) {
    score += 15;
  }
  
  // 5. Funder type alignment (10 points)
  maxScore += 10;
  if (checkFunderAlignment(org, opp)) {
    score += 10;
  }
  
  // 6. Pipeline pattern bonus (5 points)
  maxScore += 5;
  // This would check historical success patterns
  
  return Math.round((score / maxScore) * 100);
}

function checkEligibility(org, opp) {
  // Basic eligibility checks
  if (!opp.eligibilityBullets || opp.eligibilityBullets.length === 0) {
    return true; // No restrictions = eligible
  }
  
  const eligText = opp.eligibilityBullets.join(' ').toLowerCase();
  
  // Check for explicit exclusions
  if (org.applicant_type === 'nonprofit' && eligText.includes('for-profit only')) {
    return false;
  }
  
  if (org.applicant_type === 'individual' && eligText.includes('organizations only')) {
    return false;
  }
  
  return true;
}

function calculateFocusAlignment(org, opp) {
  if (!org.focus_areas || !opp.categories) {
    return 50; // Default moderate alignment
  }
  
  const orgFocus = (org.focus_areas || []).map(f => f.toLowerCase());
  const oppCategories = (opp.categories || []).map(c => c.toLowerCase());
  
  let matches = 0;
  for (const focus of orgFocus) {
    for (const cat of oppCategories) {
      if (focus.includes(cat) || cat.includes(focus)) {
        matches++;
      }
    }
  }
  
  return Math.min(100, matches * 25);
}

function checkGeographicMatch(org, opp) {
  if (!opp.geoScope || opp.geoScope === 'national' || opp.geoScope === 'international') {
    return true;
  }
  
  if (opp.geoStates && org.state) {
    return opp.geoStates.includes(org.state);
  }
  
  return true;
}

function checkAwardFit(org, opp) {
  // If no budget info, assume fit
  if (!org.annual_budget && !org.requested_amount) {
    return true;
  }
  
  // Check if award range is reasonable for org size
  const awardMax = opp.awardMax || 100000;
  const orgBudget = org.annual_budget || 50000;
  
  // Award should be between 5% and 100% of budget
  return awardMax >= orgBudget * 0.05 && awardMax <= orgBudget * 2;
}

function checkFunderAlignment(org, opp) {
  // Simple heuristic - could be expanded
  return true;
}

function getMatchReasons(org, opp, score) {
  const reasons = [];
  
  if (score >= 90) {
    reasons.push('Excellent overall fit');
  }
  
  if (checkEligibility(org, opp)) {
    reasons.push('Meets eligibility requirements');
  }
  
  if (checkGeographicMatch(org, opp)) {
    reasons.push('Geographic match');
  }
  
  if (org.focus_areas && opp.categories) {
    const overlap = org.focus_areas.some(f => 
      opp.categories.some(c => 
        f.toLowerCase().includes(c.toLowerCase()) || 
        c.toLowerCase().includes(f.toLowerCase())
      )
    );
    if (overlap) {
      reasons.push('Focus area alignment');
    }
  }
  
  return reasons;
}

async function generateMatchExplanation(org, match) {
  try {
    const prompt = `
You are a grant matching expert. Explain in 2-3 sentences why this funding opportunity is a good match for this organization.

Organization: ${org.name}
Mission: ${org.mission || 'Not specified'}
Focus Areas: ${(org.focus_areas || []).join(', ') || 'Not specified'}
Location: ${org.city || ''}, ${org.state || ''}

Opportunity: ${match.title}
Funder: ${match.sponsor}
Categories: ${(match.categories || []).join(', ')}
Award Range: $${match.awardMin || 0} - $${match.awardMax || 0}

Match Score: ${match.match_score}%

Be specific about alignment. Start with the strongest reason for the match.
`;
    
    const response = await sdk.integrations.Core.InvokeLLM({
      prompt,
      max_tokens: 200
    });
    
    return response?.trim() || null;
  } catch (err) {
    console.warn('[generateMatchExplanation] Failed:', err.message);
    return null;
  }
}
