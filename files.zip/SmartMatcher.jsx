import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Sparkles, 
  Loader2, 
  Target, 
  TrendingUp,
  Plus,
  CheckCircle2,
  AlertCircle,
  Brain,
  BarChart3,
  RefreshCw,
  Filter,
  Zap,
  GraduationCap
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { formatDateSafe } from '@/components/shared/dateUtils';
import { useRLSOrganizations, useRLSFilter } from '@/components/hooks/useAuthRLS';

// New AI-powered components
import StudentProfileAnalysis from '@/components/smart-matcher/StudentProfileAnalysis';
import MatchDetailCard from '@/components/smart-matcher/MatchDetailCard';
import ProactiveSuggestions from '@/components/smart-matcher/ProactiveSuggestions';

// ID validation patterns
const ID_PATTERN = /^[0-9a-f]{24}$/i;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isValidProfileId(id) {
  if (!id || typeof id !== 'string') return false;
  const trimmed = id.trim();
  return ID_PATTERN.test(trimmed) || UUID_PATTERN.test(trimmed);
}

/**
 * Smart Matcher - AI-Powered Grant Matching Engine
 * 
 * Analyzes organization profile and pipeline to suggest highly relevant
 * grant opportunities with match scores and detailed explanations
 * 
 * @version 2.0.0 - Fixed payload handling (removed body wrapper)
 */
export default function SmartMatcher() {
  const [selectedOrgId, setSelectedOrgId] = useState(null);
  const [minScore, setMinScore] = useState(70);
  const [isMatching, setIsMatching] = useState(false);
  const [matchResults, setMatchResults] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('matcher');

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // RLS-safe organizations
  const { 
    data: organizations = [], 
    isLoading: isLoadingOrgs,
    isLoadingUser,
    user,
    isAdmin
  } = useRLSOrganizations();

  // Auto-select first org
  React.useEffect(() => {
    if (!selectedOrgId && organizations.length > 0) {
      setSelectedOrgId(organizations[0].id);
    }
  }, [organizations, selectedOrgId]);

  const selectedOrg = organizations.find(o => o.id === selectedOrgId);

  // RLS-safe pipeline grants for context using useRLSFilter
  const { data: pipelineGrants = [] } = useRLSFilter(
    'Grant',
    { organization_id: selectedOrgId },
    { enabled: !!selectedOrgId }
  );

  const isStudent = selectedOrg && ['high_school_student', 'college_student', 'graduate_student'].includes(selectedOrg.applicant_type);

  // Run matching mutation with enhanced AI analysis
  const matchMutation = useMutation({
    mutationFn: async () => {
      // FAIL-SAFE: Validate profile ID before sending
      if (!selectedOrgId || !isValidProfileId(selectedOrgId)) {
        console.warn('[SmartMatcher] Invalid profile ID format:', selectedOrgId);
        throw new Error('The selected profile does not have a valid ID.');
      }
      
      if (!selectedOrg || !selectedOrg.id) {
        console.warn('[SmartMatcher] Selected org missing id:', selectedOrg);
        throw new Error('Please select a valid profile first.');
      }
      
      // FIX: Send payload directly WITHOUT { body: } wrapper
      // This is the standard pattern used by most other function calls
      const payload = { 
        organization_id: selectedOrg.id,
        min_score: minScore,
        max_results: 50
      };
      
      console.log('[SmartMatcher] Calling matchGrantsForOrganization with payload:', JSON.stringify(payload));
      
      // FIXED: Removed { body: payload } wrapper - send payload directly
      const response = await base44.functions.invoke('matchGrantsForOrganization', payload);
      
      console.log('[SmartMatcher] Response:', {
        success: response.data?.ok !== false,
        error: response.data?.error,
        matchCount: response.data?.data?.matches_found
      });
      
      // Handle envelope format from withAuth
      const result = response.data;
      if (result?.ok === false) {
        throw new Error(result.error || 'Matching failed');
      }
      
      return result?.data || result;
    },
    onSuccess: (data) => {
      setMatchResults(data);
      
      toast({
        title: '✅ Matching Complete',
        description: `Found ${data.matches_found || 0} relevant opportunities`,
      });
    },
    onError: (error) => {
      console.error('[SmartMatcher] Mutation error:', error);
      toast({
        variant: 'destructive',
        title: 'Matching Failed',
        description: error.message || 'Failed to run matching algorithm',
      });
    }
  });

  // Add to pipeline mutation
  const addToPipelineMutation = useMutation({
    mutationFn: async (opportunity) => {
      return await base44.entities.Grant.create({
        organization_id: selectedOrgId,
        title: opportunity.title,
        funder: opportunity.sponsor || 'Unknown',
        url: opportunity.url || '',
        deadline: opportunity.deadlineAt || null,
        award_floor: opportunity.awardMin || 0,
        award_ceiling: opportunity.awardMax || 0,
        eligibility_summary: (opportunity.eligibilityBullets || []).join('\n'),
        program_description: opportunity.descriptionMd || '',
        status: 'discovered',
        match_score: opportunity.match_score,
        ai_summary: opportunity.ai_explanation,
        opportunity_type: opportunity.fundingType || 'grant'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grants'] });
      
      toast({
        title: '✅ Added to Pipeline',
        description: 'Grant has been added to your pipeline',
      });
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Failed to Add',
        description: error.message || 'Could not add to pipeline',
      });
    }
  });

  const handleRunMatcher = () => {
    // Validate before starting
    if (!selectedOrgId) {
      toast({
        variant: 'destructive',
        title: 'No Profile Selected',
        description: 'Please select a profile to run matching.',
      });
      return;
    }
    
    if (!isValidProfileId(selectedOrgId)) {
      console.warn('[SmartMatcher] handleRunMatcher - Invalid profile ID:', selectedOrgId);
      toast({
        variant: 'destructive',
        title: 'Invalid Profile',
        description: 'The selected profile does not have a valid ID.',
      });
      return;
    }
    
    setIsMatching(true);
    matchMutation.mutate(undefined, {
      onSettled: () => setIsMatching(false)
    });
  };

  const handleAddToPipeline = (opportunity) => {
    addToPipelineMutation.mutate(opportunity);
  };

  // Filter matches by category
  const filteredMatches = React.useMemo(() => {
    if (!matchResults?.matches) return [];
    if (categoryFilter === 'all') return matchResults.matches;
    
    return matchResults.matches.filter(m => 
      m.categories?.some(c => c.toLowerCase().includes(categoryFilter.toLowerCase()))
    );
  }, [matchResults?.matches, categoryFilter]);

  // Get unique categories from results
  const availableCategories = React.useMemo(() => {
    if (!matchResults?.matches) return [];
    const cats = new Set();
    matchResults.matches.forEach(m => {
      m.categories?.forEach(c => cats.add(c));
    });
    return Array.from(cats).slice(0, 10);
  }, [matchResults?.matches]);

  // Loading state
  if (isLoadingOrgs || isLoadingUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold text-slate-900 flex items-center gap-3">
              <Brain className="w-10 h-10 text-purple-600" />
              Smart Matcher
            </h1>
            <p className="text-slate-600 mt-1">
              AI-powered grant matching engine that analyzes your profile and finds the best opportunities
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <Select value={selectedOrgId || ''} onValueChange={setSelectedOrgId}>
              <SelectTrigger className="w-[280px]">
                <SelectValue placeholder="Select profile..." />
              </SelectTrigger>
              <SelectContent>
                {organizations.map(org => (
                  <SelectItem key={org.id} value={org.id}>
                    {org.name || 'Unnamed Profile'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button
              onClick={handleRunMatcher}
              disabled={isMatching || !selectedOrgId}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isMatching ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Run Smart Match
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Tabs for different views */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="matcher" className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              Grant Matcher
            </TabsTrigger>
            {isStudent && (
              <TabsTrigger value="profile-analysis" className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4" />
                Profile Analysis
              </TabsTrigger>
            )}
            <TabsTrigger value="suggestions" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Proactive Suggestions
            </TabsTrigger>
          </TabsList>

          {/* Profile Analysis Tab (Student Only) */}
          {isStudent && (
            <TabsContent value="profile-analysis">
              <StudentProfileAnalysis 
                profile={selectedOrg} 
                pipelineGrants={pipelineGrants}
              />
            </TabsContent>
          )}

          {/* Proactive Suggestions Tab */}
          <TabsContent value="suggestions">
            <ProactiveSuggestions 
              profile={selectedOrg}
              pipelineGrants={pipelineGrants}
              onAddToPipeline={handleAddToPipeline}
            />
          </TabsContent>

        {/* Matcher Tab Content */}
        <TabsContent value="matcher">
        <>
        {/* Settings Card */}
        <Card className="shadow-lg border-0">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Filter className="w-5 h-5 text-purple-600" />
                Match Settings
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                {showFilters ? 'Hide' : 'Show'} Filters
              </Button>
            </div>
          </CardHeader>
          
          {showFilters && (
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Minimum Match Score: {minScore}%</Label>
                  <Slider
                    value={[minScore]}
                    onValueChange={(v) => setMinScore(v[0])}
                    min={50}
                    max={95}
                    step={5}
                    className="py-4"
                  />
                  <p className="text-xs text-slate-500">
                    Only show opportunities with match scores above this threshold
                  </p>
                </div>
                
                {availableCategories.length > 0 && (
                  <div className="space-y-2">
                    <Label>Filter by Category</Label>
                    <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {availableCategories.map(cat => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </CardContent>
          )}
        </Card>

        {/* Results Summary */}
        {matchResults && (
          <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-xl border-0">
            <CardContent className="p-6">
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center">
                  <p className="text-3xl font-bold">{matchResults.total_opportunities_analyzed || 0}</p>
                  <p className="text-purple-100 text-sm">Opportunities Analyzed</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold">{matchResults.matches_found || 0}</p>
                  <p className="text-purple-100 text-sm">Matches Found</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold">
                    {matchResults.matches?.length > 0 
                      ? Math.max(...matchResults.matches.map(m => m.match_score || 0))
                      : 0}%
                  </p>
                  <p className="text-purple-100 text-sm">Highest Score</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold">{filteredMatches.length}</p>
                  <p className="text-purple-100 text-sm">After Filters</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Loading State */}
        {isMatching && (
          <Card className="border-purple-200">
            <CardContent className="p-8 text-center">
              <Loader2 className="w-16 h-16 mx-auto text-purple-600 animate-spin mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Running AI-Powered Analysis
              </h3>
              <p className="text-slate-600 mb-4">
                Analyzing your profile against thousands of grant opportunities...
              </p>
              <Progress value={66} className="w-64 mx-auto" />
            </CardContent>
          </Card>
        )}

        {/* Results Grid */}
        {matchResults && !isMatching && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-900">
                Top Matches for {matchResults.organization?.name || selectedOrg?.name}
              </h2>
              <Button variant="outline" onClick={handleRunMatcher}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Re-run Analysis
              </Button>
            </div>

            <div className="grid gap-4">
              {filteredMatches.length === 0 ? (
                <Card className="border-slate-200">
                  <CardContent className="p-12 text-center">
                    <AlertCircle className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                    <h3 className="text-xl font-semibold text-slate-900 mb-2">
                      No matches found
                    </h3>
                    <p className="text-slate-600">
                      Try lowering the minimum match score or adjusting your organization profile
                    </p>
                  </CardContent>
                </Card>
              ) : (
                filteredMatches.map((match, index) => (
                  <Card 
                    key={match.id || index}
                    className="hover:shadow-xl transition-shadow border-l-4"
                    style={{
                      borderLeftColor: 
                        match.match_score >= 90 ? '#10b981' :
                        match.match_score >= 80 ? '#3b82f6' :
                        match.match_score >= 70 ? '#8b5cf6' :
                        '#64748b'
                    }}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge 
                              className="text-white font-bold"
                              style={{
                                backgroundColor:
                                  match.match_score >= 90 ? '#10b981' :
                                  match.match_score >= 80 ? '#3b82f6' :
                                  match.match_score >= 70 ? '#8b5cf6' :
                                  '#64748b'
                              }}
                            >
                              {match.match_score}% Match
                            </Badge>
                            <Badge variant="outline">
                              {match.fundingType || 'Grant'}
                            </Badge>
                          </div>
                          <CardTitle className="text-xl mb-2">
                            {match.title}
                          </CardTitle>
                          <p className="text-sm text-slate-600">
                            <strong>Funder:</strong> {match.sponsor || 'Unknown'}
                          </p>
                        </div>
                        
                        <Button
                          onClick={() => handleAddToPipeline(match)}
                          disabled={addToPipelineMutation.isPending}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add to Pipeline
                        </Button>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      {/* Award & Deadline */}
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="flex items-center gap-2 text-sm">
                          <BarChart3 className="w-4 h-4 text-blue-600" />
                          <span className="text-slate-600">Award:</span>
                          <span className="font-semibold text-slate-900">
                            ${(match.awardMin || 0).toLocaleString()} - ${(match.awardMax || 0).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <TrendingUp className="w-4 h-4 text-emerald-600" />
                          <span className="text-slate-600">Deadline:</span>
                          <span className="font-semibold text-slate-900">
                            {match.rolling ? 'Rolling' : formatDateSafe(match.deadlineAt, 'MMM d, yyyy', 'TBD')}
                          </span>
                        </div>
                      </div>

                      {/* AI Explanation */}
                      {match.ai_explanation && (
                        <Alert className="bg-purple-50 border-purple-200">
                          <Sparkles className="h-4 w-4 text-purple-600" />
                          <AlertDescription className="text-purple-900">
                            <strong>Why this matches:</strong>
                            <p className="mt-1">{match.ai_explanation}</p>
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* Match Reasons */}
                      {match.match_reasons && match.match_reasons.length > 0 && (
                        <div>
                          <p className="text-sm font-semibold text-slate-700 mb-2">
                            Match Criteria:
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {match.match_reasons.map((reason, idx) => (
                              <Badge key={idx} variant="outline" className="bg-green-50 text-green-800 border-green-300">
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                {reason}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Categories */}
                      {match.categories && match.categories.length > 0 && (
                        <div>
                          <p className="text-sm font-semibold text-slate-700 mb-2">
                            Categories:
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {match.categories.slice(0, 5).map((cat, idx) => (
                              <Badge key={idx} variant="secondary">
                                {cat}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Description Preview */}
                      {match.descriptionMd && (
                        <div>
                          <p className="text-sm text-slate-600 line-clamp-3">
                            {match.descriptionMd}
                          </p>
                        </div>
                      )}

                      {/* URL */}
                      {match.url && (
                        <div>
                          <a
                            href={match.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-blue-600 hover:text-blue-800 hover:underline"
                          >
                            View full opportunity →
                          </a>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </>
        )}

        {/* Empty State */}
        {!matchResults && !isMatching && (
          <Card>
            <CardContent className="p-12 text-center">
              <Brain className="w-20 h-20 mx-auto text-slate-300 mb-6" />
              <h3 className="text-2xl font-bold text-slate-900 mb-3">
                Ready to Find Perfect Matches
              </h3>
              <p className="text-slate-600 mb-6 max-w-2xl mx-auto">
                Our AI-powered matching engine analyzes your organization's profile, mission, 
                and current pipeline to find the most relevant grant opportunities from our 
                database of thousands of funders.
              </p>
              <div className="grid md:grid-cols-3 gap-6 max-w-3xl mx-auto text-left">
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <Target className="w-8 h-8 text-purple-600 mb-3" />
                  <h4 className="font-semibold text-slate-900 mb-2">Smart Scoring</h4>
                  <p className="text-sm text-slate-600">
                    Multi-criteria algorithm scores opportunities 0-100% based on eligibility, focus, and fit
                  </p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <Sparkles className="w-8 h-8 text-blue-600 mb-3" />
                  <h4 className="font-semibold text-slate-900 mb-2">AI Explanations</h4>
                  <p className="text-sm text-slate-600">
                    Detailed reasoning for each match, highlighting alignment with your mission and goals
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <TrendingUp className="w-8 h-8 text-green-600 mb-3" />
                  <h4 className="font-semibold text-slate-900 mb-2">Learn & Improve</h4>
                  <p className="text-sm text-slate-600">
                    Analyzes your pipeline to understand preferences and improve future recommendations
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        {/* End of matcher tab content */}
        </>
        </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
